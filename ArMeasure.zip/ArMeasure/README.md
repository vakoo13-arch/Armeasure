# AR Measure

Measures distance, height and size of objects (bottles, boxes, furniture) up to about 3 m away,
using Google ARCore. No calibration needed: ARCore works out real-world scale as you move the phone.

## Use
1. Open the app and slowly move the phone side to side for a few seconds until the circle turns green.
2. **Distance**: shown at the top. It's the distance from the phone to whatever the circle is on.
3. **Size**: put the circle on one end of the object, tap **+**, move to the other end, tap **+**.
4. **Height**: put the circle where the object stands (the table or floor at its base), tap **+**,
   then raise the circle to the top of the object and tap **+**. The top does not need a surface.

## Tips
- Good light and surfaces with some texture help. Plain white walls and glossy tables are hard.
- Typical accuracy is about 1–2 cm at arm's length and a few cm at 3 m.
- The phone needs ARCore support (most phones from the last few years). The app will ask to
  install "Google Play Services for AR" if it's missing.

## Code
- `MeasureRenderer.kt`: ARCore session, center hit test, anchors, projection to screen.
- `Geometry.kt`: pure math (height from camera ray, projection), unit-tested in `app/src/test`.
- `MeasureScreen.kt`: Compose overlay (target circle, lines, labels, buttons).
