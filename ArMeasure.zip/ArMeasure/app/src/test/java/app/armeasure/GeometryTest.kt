package app.armeasure

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeometryTest {

    @Test
    fun heightOfBottleSeenFromAbove() {
        // Bottle base on a table 1.5 m in front of the camera; camera held 0.4 m above the table.
        val base = Vec3(0.0, 0.0, -1.5)
        val cam = Vec3(0.2, 0.4, 0.0)
        // Aim exactly at the bottle top, 0.30 m above the base.
        val top = Vec3(0.0, 0.30, -1.5)
        val h = Geometry.heightOnVerticalLine(base, cam, top - cam)
        assertNotNull(h)
        assertEquals(0.30, h!!, 1e-9)
    }

    @Test
    fun heightIgnoresSidewaysAimError() {
        // Aim 2 cm to the side of the top: height should barely change.
        val base = Vec3(0.0, 0.0, -2.0)
        val cam = Vec3(0.0, 1.2, 0.0)
        val aim = Vec3(0.02, 0.85, -2.0)
        val h = Geometry.heightOnVerticalLine(base, cam, aim - cam)!!
        assertEquals(0.85, h, 0.001)
    }

    @Test
    fun noHeightWhenLookingStraightDownOrAway() {
        val base = Vec3(0.0, 0.0, -1.0)
        val cam = Vec3(0.0, 1.0, 0.0)
        assertEquals(null, Geometry.heightOnVerticalLine(base, cam, Vec3(0.0, -1.0, 0.0)))
        assertEquals(null, Geometry.heightOnVerticalLine(base, cam, Vec3(0.0, 0.0, 1.0)))
    }

    @Test
    fun projectCenterPoint() {
        // Identity view-projection: the origin lands in the screen center.
        val id = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
        val p = Geometry.project(Vec3(0.0, 0.0, 0.0), id, 1000, 2000)!!
        assertEquals(500f, p.first, 1e-3f)
        assertEquals(1000f, p.second, 1e-3f)
        val corner = Geometry.project(Vec3(1.0, 1.0, 0.0), id, 1000, 2000)!!
        assertEquals(1000f, corner.first, 1e-3f)
        assertEquals(0f, corner.second, 1e-3f)
    }

    @Test
    fun formatting() {
        assertTrue(Geometry.format(0.234).startsWith("23.4"))
        assertTrue(Geometry.format(1.236).startsWith("1.24"))
    }
}
