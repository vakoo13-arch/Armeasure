package app.armeasure

import kotlin.math.abs
import kotlin.math.sqrt

data class Vec3(val x: Double, val y: Double, val z: Double) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Double) = Vec3(x * s, y * s, z * s)
    infix fun dot(o: Vec3) = x * o.x + y * o.y + z * o.z
    fun length() = sqrt(this dot this)
    fun normalized(): Vec3 {
        val l = length()
        return if (l < 1e-12) this else this * (1.0 / l)
    }

    companion object {
        val UP = Vec3(0.0, 1.0, 0.0)
    }
}

object Geometry {

    fun distance(a: Vec3, b: Vec3): Double = (a - b).length()

    /**
     * Height of an object standing at [base]: where the camera ray (aimed at the object's top)
     * passes closest to the vertical line through the base. ARCore's world Y axis points up
     * (against gravity), so this works even when the top has no surface to hit.
     *
     * @return height in meters above the base, or null if the ray is (almost) vertical
     *   or points away from the line.
     */
    fun heightOnVerticalLine(base: Vec3, rayOrigin: Vec3, rayDir: Vec3): Double? {
        val u = Vec3.UP
        val d = rayDir.normalized()
        val w0 = base - rayOrigin
        val b = u dot d
        val den = 1.0 - b * b
        if (den < 1e-4) return null
        val dd = u dot w0
        val e = d dot w0
        val t = (b * e - dd) / den      // position along the vertical line
        val s = (e - b * dd) / den      // position along the ray
        if (s <= 0) return null
        return t
    }

    /**
     * Projects a world point to screen pixels using a column-major view-projection matrix.
     * Returns null for points behind the camera.
     */
    fun project(p: Vec3, viewProj: FloatArray, width: Int, height: Int): Pair<Float, Float>? {
        val m = viewProj
        val cx = m[0] * p.x + m[4] * p.y + m[8] * p.z + m[12]
        val cy = m[1] * p.x + m[5] * p.y + m[9] * p.z + m[13]
        val cw = m[3] * p.x + m[7] * p.y + m[11] * p.z + m[15]
        if (cw <= 1e-6) return null
        val nx = cx / cw
        val ny = cy / cw
        return ((nx + 1) / 2 * width).toFloat() to ((1 - ny) / 2 * height).toFloat()
    }

    /** "23.4 cm" below one meter, "1.24 m" above. */
    fun format(meters: Double): String =
        if (abs(meters) < 1.0) "%.1f cm".format(meters * 100) else "%.2f m".format(meters)
}
