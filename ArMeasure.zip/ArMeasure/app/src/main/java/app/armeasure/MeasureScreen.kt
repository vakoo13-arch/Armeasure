package app.armeasure

import android.opengl.GLSurfaceView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Accent = Color(0xFFFFD54F)
private val Panel = Color(0xCC000000)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalTextApi::class)
@Composable
fun MeasureScreen(
    glView: GLSurfaceView,
    state: UiState,
    error: String?,
    mode: Mode,
    onMode: (Mode) -> Unit,
    onAction: (Action) -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val measurer = rememberTextMeasurer()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ glView }, Modifier.fillMaxSize())

        // Lines, points, labels and the center target.
        Canvas(Modifier.fillMaxSize()) {
            for (s in state.segments) {
                val a = Offset(s.x1, s.y1)
                val b = Offset(s.x2, s.y2)
                drawLine(Color(0x88000000), a, b, strokeWidth = 10f)
                drawLine(
                    if (s.live) Accent else Color.White, a, b, strokeWidth = 5f,
                    pathEffect = if (s.live) PathEffect.dashPathEffect(floatArrayOf(24f, 14f)) else null,
                )
                val layout = measurer.measure(
                    s.label, TextStyle(color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Bold),
                )
                val mid = Offset((s.x1 + s.x2) / 2, (s.y1 + s.y2) / 2)
                val pad = 12f
                val tl = Offset(mid.x - layout.size.width / 2f - pad, mid.y - layout.size.height / 2f - pad / 2)
                drawRoundRect(
                    if (s.live) Accent else Color.White, tl,
                    Size(layout.size.width + pad * 2, layout.size.height + pad),
                    CornerRadius(20f, 20f),
                )
                drawText(layout, topLeft = Offset(tl.x + pad, tl.y + pad / 2))
            }
            for (p in state.points) {
                drawCircle(Color.White, 12f, Offset(p.first, p.second))
                drawCircle(Color(0xFF00B0FF), 7f, Offset(p.first, p.second))
            }
            val c = center
            val ring = if (state.targetFound) Color(0xFF69F0AE) else Color.White
            drawCircle(Color(0x66000000), 46f, c, style = Stroke(8f))
            drawCircle(ring, 44f, c, style = Stroke(4f))
            drawCircle(ring, 6f, c)
        }

        // Top: distance and hints.
        Column(
            Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                Modifier.background(Panel, RoundedCornerShape(16.dp)).padding(horizontal = 20.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Distance", color = Color.LightGray, fontSize = 13.sp)
                    Text(
                        state.distance?.let { Geometry.format(it) } ?: "--",
                        color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
            val hint = error ?: state.message
            if (hint != null) {
                Text(
                    hint,
                    color = if (error != null) MaterialTheme.colorScheme.error else Color.White,
                    modifier = Modifier.background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
        }

        // Bottom: results, instructions, controls.
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .background(Panel).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (state.results.isNotEmpty()) {
                Text(
                    state.results.takeLast(3).joinToString("   ·   "),
                    color = Color.White, fontSize = 14.sp,
                )
            }
            state.liveValue?.let {
                Text(it, color = Accent, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Text(instruction(mode, state.waitingSecond), color = Color.LightGray, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = mode == Mode.SIZE, onClick = { onMode(Mode.SIZE) }, label = { Text("Size") })
                FilterChip(selected = mode == Mode.HEIGHT, onClick = { onMode(Mode.HEIGHT) }, label = { Text("Height") })
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(onClick = { onAction(Action.UNDO) }) { Text("Undo") }
                Button(
                    onClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        onAction(Action.ADD)
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                    modifier = Modifier.size(72.dp),
                ) { Text("+", fontSize = 32.sp) }
                OutlinedButton(onClick = { onAction(Action.CLEAR) }) { Text("Clear") }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

private fun instruction(mode: Mode, waitingSecond: Boolean): String = when (mode) {
    Mode.SIZE ->
        if (!waitingSecond) "Put the circle on one end of the object and tap +"
        else "Move the circle to the other end and tap +"
    Mode.HEIGHT ->
        if (!waitingSecond) "Put the circle on the bottom of the object, where it stands, and tap +"
        else "Raise the circle to the top of the object and tap +"
}
