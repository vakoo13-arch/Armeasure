package app.armeasure

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.google.ar.core.Anchor
import com.google.ar.core.Camera
import com.google.ar.core.DepthPoint
import com.google.ar.core.Frame
import com.google.ar.core.HitResult
import com.google.ar.core.Plane
import com.google.ar.core.Point
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingFailureReason
import com.google.ar.core.TrackingState
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

enum class Mode { SIZE, HEIGHT }

enum class Action { ADD, UNDO, CLEAR }

/** Internal: drop the half-finished measurement (e.g. when switching modes). */
private object CancelPending

/** A line on screen with a label (pixels of the AR view). */
data class Segment(
    val x1: Float, val y1: Float,
    val x2: Float, val y2: Float,
    val label: String,
    val live: Boolean,
)

data class UiState(
    val message: String? = "Starting camera…",
    /** Distance from the phone to whatever the center circle is on, in meters. */
    val distance: Double? = null,
    val targetFound: Boolean = false,
    val segments: List<Segment> = emptyList(),
    val points: List<Pair<Float, Float>> = emptyList(),
    /** Live value while the second point is being aimed. */
    val liveValue: String? = null,
    val results: List<String> = emptyList(),
    val waitingSecond: Boolean = false,
)

private sealed class Measurement {
    abstract fun detach()

    class Size(val a: Anchor, val b: Anchor) : Measurement() {
        override fun detach() { a.detach(); b.detach() }
    }

    class Height(val base: Anchor, val height: Double) : Measurement() {
        override fun detach() = base.detach()
    }
}

/**
 * Runs on the GL thread: draws the camera, hit-tests the screen center every frame,
 * keeps measurements as ARCore anchors and projects them to screen for the overlay.
 */
class MeasureRenderer(
    private val displayRotation: () -> Int,
    private val onState: (UiState) -> Unit,
) : GLSurfaceView.Renderer {

    @Volatile var session: Session? = null

    @Volatile var mode: Mode = Mode.SIZE
        set(value) {
            if (field != value) actions.add(CancelPending)
            field = value
        }

    private val actions = ConcurrentLinkedQueue<Any>()
    private val background = BackgroundRenderer()
    private var boundSession: Session? = null
    private var width = 1
    private var height = 1
    private var lastRotation = -1
    private var sizeChanged = true

    private var pending: Anchor? = null
    private val measurements = ArrayList<Measurement>()

    private val view = FloatArray(16)
    private val proj = FloatArray(16)
    private val viewProj = FloatArray(16)

    fun post(action: Action) {
        actions.add(action)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        background.create()
        boundSession = null
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        width = w
        height = h
        sizeChanged = true
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val s = session ?: return
        if (boundSession !== s) {
            s.setCameraTextureName(background.textureId)
            boundSession = s
            sizeChanged = true
        }
        val rot = displayRotation()
        if (sizeChanged || rot != lastRotation) {
            s.setDisplayGeometry(rot, width, height)
            sizeChanged = false
            lastRotation = rot
        }
        val frame = try {
            s.update()
        } catch (e: Exception) {
            Log.w("ArMeasure", "update failed", e)
            return
        }
        background.draw(frame)

        val camera = frame.camera
        if (camera.trackingState != TrackingState.TRACKING) {
            drainActions(null, null, camera)
            onState(buildState(trackingMessage(camera), null, null, camera))
            return
        }
        camera.getViewMatrix(view, 0)
        camera.getProjectionMatrix(proj, 0, 0.05f, 100f)
        Matrix.multiplyMM(viewProj, 0, proj, 0, view, 0)

        val hit = centerHit(frame)
        val liveHeight = pending?.takeIf { mode == Mode.HEIGHT }?.let { heightFromCamera(it, camera) }
        drainActions(hit, liveHeight, camera)

        val message = when {
            hit == null && !(mode == Mode.HEIGHT && pending != null) ->
                "Aim at a surface. Move the phone slowly to scan."
            else -> null
        }
        onState(buildState(message, hit, liveHeight, camera))
    }

    private fun drainActions(hit: HitResult?, liveHeight: Double?, camera: Camera) {
        while (true) {
            val a = actions.poll() ?: break
            when (a) {
                Action.ADD -> add(hit, liveHeight)
                Action.UNDO -> {
                    val p = pending
                    if (p != null) {
                        p.detach(); pending = null
                    } else if (measurements.isNotEmpty()) {
                        measurements.removeAt(measurements.lastIndex).detach()
                    }
                }
                Action.CLEAR -> {
                    pending?.detach(); pending = null
                    measurements.forEach { it.detach() }
                    measurements.clear()
                }
                CancelPending -> {
                    pending?.detach(); pending = null
                }
            }
        }
    }

    private fun add(hit: HitResult?, liveHeight: Double?) {
        val p = pending
        when (mode) {
            Mode.SIZE -> {
                hit ?: return
                val anchor = hit.createAnchor()
                if (p == null) {
                    pending = anchor
                } else {
                    measurements.add(Measurement.Size(p, anchor))
                    pending = null
                }
            }
            Mode.HEIGHT -> {
                if (p == null) {
                    hit ?: return
                    pending = hit.createAnchor()
                } else {
                    val h = liveHeight ?: return
                    if (h < 0.005) return
                    measurements.add(Measurement.Height(p, h))
                    pending = null
                }
            }
        }
    }

    /** Best hit at the screen center: planes, depth points, or oriented feature points. */
    private fun centerHit(frame: Frame): HitResult? {
        for (hit in frame.hitTest(width / 2f, height / 2f)) {
            val ok = when (val t = hit.trackable) {
                is Plane -> t.trackingState == TrackingState.TRACKING && t.isPoseInPolygon(hit.hitPose)
                is DepthPoint -> true
                is Point -> t.orientationMode == Point.OrientationMode.ESTIMATED_SURFACE_NORMAL
                else -> false
            }
            if (ok) return hit
        }
        return null
    }

    private fun heightFromCamera(base: Anchor, camera: Camera): Double? {
        val pose = camera.pose
        val z = pose.zAxis // the camera looks along -Z
        val dir = Vec3(-z[0].toDouble(), -z[1].toDouble(), -z[2].toDouble())
        return Geometry.heightOnVerticalLine(base.pose.vec(), pose.vec(), dir)
    }

    private fun buildState(message: String?, hit: HitResult?, liveHeight: Double?, camera: Camera): UiState {
        val tracking = camera.trackingState == TrackingState.TRACKING
        val segments = ArrayList<Segment>()
        val points = ArrayList<Pair<Float, Float>>()
        val results = ArrayList<String>()

        fun addSeg(a: Vec3, b: Vec3, label: String, live: Boolean) {
            if (!tracking) return
            val pa = Geometry.project(a, viewProj, width, height) ?: return
            val pb = Geometry.project(b, viewProj, width, height) ?: return
            segments.add(Segment(pa.first, pa.second, pb.first, pb.second, label, live))
            points.add(pa); points.add(pb)
        }

        measurements.forEachIndexed { i, m ->
            when (m) {
                is Measurement.Size -> {
                    val a = m.a.pose.vec()
                    val b = m.b.pose.vec()
                    val label = Geometry.format(Geometry.distance(a, b))
                    results.add("Size ${i + 1}: $label")
                    addSeg(a, b, label, false)
                }
                is Measurement.Height -> {
                    val base = m.base.pose.vec()
                    val label = Geometry.format(m.height)
                    results.add("Height ${i + 1}: $label")
                    addSeg(base, base + Vec3.UP * m.height, label, false)
                }
            }
        }

        var liveValue: String? = null
        val p = pending
        if (p != null && tracking) {
            val a = p.pose.vec()
            when (mode) {
                Mode.SIZE -> if (hit != null) {
                    val b = hit.hitPose.vec()
                    liveValue = Geometry.format(Geometry.distance(a, b))
                    addSeg(a, b, liveValue, true)
                } else {
                    Geometry.project(a, viewProj, width, height)?.let { points.add(it) }
                }
                Mode.HEIGHT -> if (liveHeight != null && liveHeight > 0) {
                    liveValue = Geometry.format(liveHeight)
                    addSeg(a, a + Vec3.UP * liveHeight, liveValue, true)
                } else {
                    Geometry.project(a, viewProj, width, height)?.let { points.add(it) }
                }
            }
        }

        return UiState(
            message = message,
            distance = hit?.distance?.toDouble(),
            targetFound = hit != null,
            segments = segments,
            points = points,
            liveValue = liveValue,
            results = results,
            waitingSecond = pending != null,
        )
    }

    private fun trackingMessage(camera: Camera): String = when (camera.trackingFailureReason) {
        TrackingFailureReason.INSUFFICIENT_LIGHT -> "Too dark. Turn on more light."
        TrackingFailureReason.EXCESSIVE_MOTION -> "Moving too fast. Move the phone slowly."
        TrackingFailureReason.INSUFFICIENT_FEATURES -> "Point at a surface with some texture or detail."
        TrackingFailureReason.CAMERA_UNAVAILABLE -> "Camera unavailable. Close other camera apps."
        else -> "Move the phone slowly from side to side to start."
    }

    private fun Pose.vec() = Vec3(tx().toDouble(), ty().toDouble(), tz().toDouble())
}
