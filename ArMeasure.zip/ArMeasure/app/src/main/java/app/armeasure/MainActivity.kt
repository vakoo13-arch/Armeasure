package app.armeasure

import android.Manifest
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableApkTooOldException
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException

class MainActivity : ComponentActivity() {

    private var session: Session? = null
    private var installRequested = false
    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: MeasureRenderer

    private var uiState by mutableStateOf(UiState())
    private var error by mutableStateOf<String?>(null)
    private var mode by mutableStateOf(Mode.SIZE)

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) error = "Camera permission is needed to measure."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        @Suppress("DEPRECATION")
        renderer = MeasureRenderer(
            displayRotation = { windowManager.defaultDisplay.rotation },
            onState = { s -> runOnUiThread { uiState = s } },
        )
        glView = GLSurfaceView(this).apply {
            preserveEGLContextOnPause = true
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                MeasureScreen(
                    glView = glView,
                    state = uiState,
                    error = error,
                    mode = mode,
                    onMode = { mode = it; renderer.mode = it },
                    onAction = renderer::post,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permission.launch(Manifest.permission.CAMERA)
            return
        }
        if (session == null) {
            try {
                when (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                    ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                        installRequested = true
                        return
                    }
                    else -> {}
                }
                session = Session(this).also { configure(it) }
            } catch (e: UnavailableUserDeclinedInstallationException) {
                error = "Please install \"Google Play Services for AR\" from the Play Store."
                return
            } catch (e: UnavailableApkTooOldException) {
                error = "Please update \"Google Play Services for AR\" in the Play Store."
                return
            } catch (e: UnavailableDeviceNotCompatibleException) {
                error = "Sorry, this phone doesn't support ARCore."
                return
            } catch (e: Exception) {
                error = "AR couldn't start: ${e.message}"
                return
            }
        }
        try {
            session?.resume()
        } catch (e: CameraNotAvailableException) {
            error = "Camera not available. Close other camera apps and try again."
            session = null
            return
        }
        error = null
        renderer.session = session
        glView.onResume()
    }

    private fun configure(s: Session) {
        val config = Config(s)
        // Depth makes measuring non-flat objects (bottles, boxes) much more reliable.
        config.depthMode = if (s.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) {
            Config.DepthMode.AUTOMATIC
        } else {
            Config.DepthMode.DISABLED
        }
        config.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
        config.focusMode = Config.FocusMode.AUTO
        s.configure(config)
    }

    override fun onPause() {
        super.onPause()
        if (session != null) {
            glView.onPause()
            session?.pause()
        }
    }

    override fun onDestroy() {
        renderer.session = null
        session?.close()
        session = null
        super.onDestroy()
    }
}
